Setup Instructions
1. Download and Unzip: Start by downloading the compressed file. Once downloaded, unzip the file to access the project contents.

2. Java Development Kit (JDK): Ensure that you have JDK 11 installed on your system, as this project is built using JDK 11.

3. Source Packages: Navigate to the source packages folder where you will find 6 files. Locate and open the control file.

4. Running the Program: Inside the control file, you will find the Main file. Open this file to start the program. No username or password is required to run the program.