/**
 * Entity class for Donor Management subsystem of the CareNet Charity Centre Management System.
 *
 * Author: Ling Jit Xuan
 * Student Id: 2409231
 */
package entity;

public enum Gender {
    MALE, FEMALE, OTHERS;
}
